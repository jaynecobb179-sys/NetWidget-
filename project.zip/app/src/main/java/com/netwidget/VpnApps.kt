@file:Suppress("DEPRECATION")

package com.netwidget

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Process

/** Поиск VPN-приложений и (best effort) определение, какое из них сейчас держит VPN. */
object VpnApps {
    // Ищем по названию приложения, чтобы не зависеть от package name
    private val KEYWORDS = listOf("hiro", "happ", "amnezia", "v2ray")

    data class App(val pkg: String, val label: String)

    fun launchable(ctx: Context): List<App> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { App(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .distinctBy { it.pkg }
            .filter { it.pkg != ctx.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun installed(ctx: Context): List<App> {
        val extra = Store.prefs(ctx).getStringSet("extraPkgs", emptySet()) ?: emptySet()
        return launchable(ctx).filter { a ->
            a.pkg in extra || KEYWORDS.any { a.label.contains(it, ignoreCase = true) }
        }
    }

    fun label(ctx: Context, pkg: String): String? = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    fun hasUsageAccess(ctx: Context): Boolean {
        val am = ctx.getSystemService(AppOpsManager::class.java)
        return am.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    fun markActive(ctx: Context, pkg: String) {
        Store.prefs(ctx).edit().putString("activeVpn", pkg).apply()
        NetWorker.enqueue(ctx, "name")
    }

    fun clear(ctx: Context) {
        val sp = Store.prefs(ctx)
        if (sp.contains("activeVpn") || sp.getLong("vpnHandle", -1) != -1L) {
            sp.edit().remove("activeVpn").putLong("vpnHandle", -1).apply()
        }
    }

    /**
     * Android не отдаёт имя приложения, владеющего VPN. Поэтому:
     * 0) постоянное уведомление VPN-клиента (нужен доступ к уведомлениям) — самый надёжный способ;
     * 1) если VPN-сеть новая — ищем, какое из VPN-приложений было открыто в последние 10 минут
     *    (нужен доступ к статистике использования);
     * 2) иначе — приложение, которое открыли из нашего экрана;
     * 3) иначе — имя неизвестно (можно отметить долгим нажатием в приложении).
     */
    fun resolveActive(ctx: Context, handle: Long): String? {
        val sp = Store.prefs(ctx)
        if (sp.getLong("vpnHandle", -1) != handle) {
            sp.edit().putLong("vpnHandle", handle).remove("activeVpn").apply()
        }
        val pkgs = installed(ctx).map { it.pkg }
        VpnNotificationListener.active(ctx, pkgs)?.let { pkg ->
            if (sp.getString("activeVpn", null) != pkg) sp.edit().putString("activeVpn", pkg).apply()
            return label(ctx, pkg) ?: pkg
        }
        sp.getString("activeVpn", null)?.let { return label(ctx, it) ?: it }

        val now = System.currentTimeMillis()
        val found = fromUsage(ctx, pkgs)
            ?: sp.getString("launchedPkg", null)
                ?.takeIf { now - sp.getLong("launchedAt", 0) < 10 * 60_000L }
        if (found != null) {
            sp.edit().putString("activeVpn", found).apply()
            return label(ctx, found) ?: found
        }
        return null
    }

    private fun fromUsage(ctx: Context, pkgs: List<String>): String? {
        if (pkgs.isEmpty() || !hasUsageAccess(ctx)) return null
        val usm = ctx.getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 10 * 60_000L, now)
        val e = UsageEvents.Event()
        var best: String? = null
        var t = 0L
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED &&
                e.packageName in pkgs && e.timeStamp >= t
            ) {
                best = e.packageName; t = e.timeStamp
            }
        }
        return best
    }
}
