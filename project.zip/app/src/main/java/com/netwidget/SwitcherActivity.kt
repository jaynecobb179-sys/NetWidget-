package com.netwidget

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Экран, который открывается по нажатию на виджет: статус сети + быстрый запуск VPN-сервисов. */
class SwitcherActivity : Activity() {

    private lateinit var content: LinearLayout

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        runOnUiThread { render() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(32))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            addView(content)
        }
        setContentView(scroll)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom)
            insets
        }
    }

    override fun onResume() {
        super.onResume()
        Store.prefs(this).registerOnSharedPreferenceChangeListener(listener)
        NetWidget.registerCallback(this)
        NetWorker.schedulePeriodic(this)
        NetWorker.enqueue(this, "net")
        render()
    }

    override fun onPause() {
        super.onPause()
        Store.prefs(this).unregisterOnSharedPreferenceChangeListener(listener)
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun add(v: View, top: Int = 12) {
        content.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
    }

    private fun card(block: LinearLayout.() -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Ui.CARD, 20)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        block()
    }

    private fun button(label: String, filled: Boolean = true, onClick: () -> Unit) =
        text(label, 14f, if (filled) Color.WHITE else Ui.ACCENT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = shape(if (filled) Ui.ACCENT else 0x1F3B82F6, 14)
            setOnClickListener { onClick() }
        }

    private fun section(t: String) = text(t, 12f, Ui.MUTED, true).apply { letterSpacing = 0.08f }

    // ---------- UI ----------
    private fun render() {
        content.removeAllViews()
        val s = Store.load(this)
        val sp = Store.prefs(this)

        add(text("Сеть и VPN", 28f, Ui.TEXT, true), 8)
        add(text("Состояние сети и быстрый запуск VPN-сервисов", 13f, Ui.MUTED), 2)
        add(statusCard(s), 16)

        add(section("VPN-СЕРВИСЫ"), 24)
        val apps = VpnApps.installed(this)
        if (apps.isEmpty()) {
            add(text("Не нашёл Hiro, Happ, Amnezia или v2ray. Добавьте приложение вручную.", 13f, Ui.MUTED), 8)
        }
        val activePkg = sp.getString("activeVpn", null)
        for (a in apps) add(appCard(a, s.vpnOn && activePkg == a.pkg), 10)
        add(button("+ Добавить приложение", false) { pickApp() }, 10)
        add(
            text(
                "Android не позволяет одному приложению включать VPN или менять сервер в другом. " +
                    "Нажатие открывает приложение сервиса — подключиться и выбрать сервер нужно там. " +
                    "Долгое нажатие на карточку отмечает этот VPN как активный (для подписи в виджете).",
                12f, Ui.MUTED
            ), 10
        )

        add(section("ДОСТУПЫ"), 24)
        val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val bg = checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
        add(permRow("Геолокация", "Нужна, чтобы показывать имя Wi-Fi. Геолокация в шторке должна быть включена.", fine) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }, 10)
        add(permRow("Геолокация «всегда»", "Чтобы имя Wi-Fi обновлялось, когда приложение закрыто.", bg) {
            if (!fine) Toast.makeText(this, "Сначала разрешите геолокацию", Toast.LENGTH_SHORT).show()
            else requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
        }, 10)
        add(permRow("Статистика использования", "Помогает определить, какой VPN включён (по тому, какое приложение открывали).", VpnApps.hasUsageAccess(this)) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }, 10)

        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            add(button("Добавить виджет 2×2 на экран") {
                mgr.requestPinAppWidget(ComponentName(this, NetWidget::class.java), null, null)
            }, 16)
            add(button("Добавить виджет 4×1 на экран", false) {
                mgr.requestPinAppWidget(ComponentName(this, NetWidgetWide::class.java), null, null)
            }, 8)
        }
    }

    private fun statusCard(s: NetState): LinearLayout {
        val l = s.look()
        val c = this
        return card {
            val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(View(c).apply { background = shape(l.dot, 10) }, LinearLayout.LayoutParams(dp(10), dp(10)))
            row.addView(text(l.title, 15f, Ui.TEXT, true).apply { setPadding(dp(8), 0, 0, 0) })
            addView(row)

            val big = LinearLayout(c).apply { gravity = Gravity.BOTTOM }
            big.addView(text(l.speed, 44f, Ui.TEXT, true))
            big.addView(text("Мбит/с", 14f, Ui.MUTED).apply { setPadding(dp(8), 0, 0, dp(8)) })
            addView(big)

            addView(text(l.net, 14f, Ui.TEXT))
            addView(text(l.vpnTitle, 14f, if (s.vpnOn) Ui.VIOLET else Ui.MUTED, true).apply {
                setPadding(0, dp(10), 0, 0)
            })
            addView(text(l.vpnDetail, 13f, l.detailColor))
            addView(
                button("Обновить", false) { NetWorker.enqueue(c, "manual") },
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
            )
        }
    }

    private fun appCard(a: VpnApps.App, active: Boolean): LinearLayout {
        val c = this
        return card {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(c).apply {
                runCatching { setImageDrawable(packageManager.getApplicationIcon(a.pkg)) }
            }, LinearLayout.LayoutParams(dp(44), dp(44)))
            val col = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), 0, 0, 0)
            }
            col.addView(text(a.label, 16f, Ui.TEXT, true))
            col.addView(
                if (active) text("● Активен сейчас", 12f, Ui.GREEN)
                else text("Нажмите, чтобы открыть", 12f, Ui.MUTED)
            )
            addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            addView(text("›", 26f, Ui.MUTED))
            setOnClickListener { launch(a) }
            setOnLongClickListener {
                VpnApps.markActive(c, a.pkg)
                Toast.makeText(c, "${a.label} отмечен как активный", Toast.LENGTH_SHORT).show()
                true
            }
        }
    }

    private fun permRow(title: String, sub: String, ok: Boolean, action: () -> Unit): LinearLayout {
        val c = this
        return card {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            col.addView(text(title, 15f, Ui.TEXT, true))
            col.addView(text(sub, 12f, Ui.MUTED))
            addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            addView(
                if (ok) text("✓", 22f, Ui.GREEN, true) else button("Разрешить") { action() },
                LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(12) }
            )
        }
    }

    private fun launch(a: VpnApps.App) {
        Store.prefs(this).edit()
            .putString("launchedPkg", a.pkg)
            .putLong("launchedAt", System.currentTimeMillis())
            .apply()
        val i = packageManager.getLaunchIntentForPackage(a.pkg)
        if (i != null) startActivity(i)
        else Toast.makeText(this, "Не удалось открыть ${a.label}", Toast.LENGTH_SHORT).show()
    }

    private fun pickApp() {
        val all = VpnApps.launchable(this)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Добавить приложение")
            .setItems(all.map { it.label }.toTypedArray()) { _, i ->
                val sp = Store.prefs(this)
                val set = (sp.getStringSet("extraPkgs", emptySet()) ?: emptySet()).toMutableSet()
                set.add(all[i].pkg)
                sp.edit().putStringSet("extraPkgs", set).apply()
            }
            .show()
    }
}
