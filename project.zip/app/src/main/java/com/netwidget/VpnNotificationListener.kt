package com.netwidget

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat

/**
 * Читает только уведомления ваших VPN-клиентов: пока VPN работает, клиент показывает
 * постоянное уведомление — по нему и определяем, какой именно VPN включён.
 */
class VpnNotificationListener : NotificationListenerService() {

    private var cand: Set<String> = emptySet()
    private var candAt = 0L

    private fun candidates(): Set<String> {
        val now = System.currentTimeMillis()
        if (now - candAt > 60_000L) {
            cand = VpnApps.installed(applicationContext).map { it.pkg }.toSet()
            candAt = now
        }
        return cand
    }

    private var lastSeen: String? = null

    override fun onListenerConnected() {
        instance = this
        NetWorker.enqueue(applicationContext, "name")
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg in candidates() && lastSeen != pkg) {
            lastSeen = pkg
            NetWorker.enqueue(applicationContext, "name", 2)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg in candidates() && lastSeen == pkg) {
            lastSeen = null
            NetWorker.enqueue(applicationContext, "name", 2)
        }
    }

    companion object {
        @Volatile
        var instance: VpnNotificationListener? = null

        fun hasAccess(ctx: Context): Boolean =
            NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

        /** Пакет VPN-клиента с постоянным (foreground/ongoing) уведомлением или null. */
        fun active(ctx: Context, pkgs: List<String>): String? {
            if (pkgs.isEmpty() || !hasAccess(ctx)) return null
            val svc = instance
            if (svc == null) {
                runCatching {
                    NotificationListenerService.requestRebind(
                        ComponentName(ctx, VpnNotificationListener::class.java)
                    )
                }
                return null
            }
            val list = runCatching { svc.activeNotifications }.getOrNull() ?: return null
            val mask = Notification.FLAG_FOREGROUND_SERVICE or Notification.FLAG_ONGOING_EVENT
            return list
                .filter { it.packageName in pkgs && (it.notification.flags and mask) != 0 }
                .maxByOrNull { it.postTime }
                ?.packageName
        }
    }
}
