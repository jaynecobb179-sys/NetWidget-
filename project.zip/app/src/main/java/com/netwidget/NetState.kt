package com.netwidget

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

object Ui {
    val BG = 0xFF0B1020.toInt()
    val CARD = 0xFF151C30.toInt()
    val TEXT = 0xFFF2F5FA.toInt()
    val MUTED = 0xFF8F9BB3.toInt()
    val GREEN = 0xFF3DDC97.toInt()
    val AMBER = 0xFFFFB020.toInt()
    val RED = 0xFFFF5C6C.toInt()
    val VIOLET = 0xFFA99BFF.toInt()
    val ACCENT = 0xFF3B82F6.toInt()
}

data class NetState(
    val updatedAt: Long = 0L,
    val connected: Boolean = false,      // есть физическая сеть
    val internet: Boolean = false,       // реальный доступ в интернет (наша проверка)
    val transport: String = "none",      // wifi | cell | other | none
    val ssid: String? = null,
    val speedMbps: Double? = null,
    val vpnOn: Boolean = false,
    val vpnName: String? = null,
    val pingMs: Int? = null,
    val tlsError: String? = null,
    val measuring: Boolean = false,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("t", updatedAt); put("c", connected); put("i", internet); put("tr", transport)
        put("ssid", ssid ?: JSONObject.NULL); put("sp", speedMbps ?: JSONObject.NULL)
        put("v", vpnOn); put("vn", vpnName ?: JSONObject.NULL)
        put("p", pingMs ?: JSONObject.NULL); put("e", tlsError ?: JSONObject.NULL)
        put("m", measuring)
    }

    companion object {
        fun fromJson(o: JSONObject) = NetState(
            updatedAt = o.optLong("t"),
            connected = o.optBoolean("c"),
            internet = o.optBoolean("i"),
            transport = o.optString("tr", "none"),
            ssid = if (o.isNull("ssid")) null else o.getString("ssid"),
            speedMbps = if (o.isNull("sp")) null else o.getDouble("sp"),
            vpnOn = o.optBoolean("v"),
            vpnName = if (o.isNull("vn")) null else o.getString("vn"),
            pingMs = if (o.isNull("p")) null else o.getInt("p"),
            tlsError = if (o.isNull("e")) null else o.getString("e"),
            measuring = o.optBoolean("m"),
        )
    }
}

/** Готовые строки и цвета для виджета и экрана. */
class Look(
    val dot: Int,
    val title: String,
    val speed: String,
    val net: String,
    val vpnTitle: String,
    val vpnDetail: String,
    val detailColor: Int,
    val compactVpn: String,
    val compactColor: Int,
)

fun NetState.look(): Look {
    val (dot, title) = when {
        updatedAt == 0L && !connected -> Ui.MUTED to "Обновление…"
        !connected -> Ui.RED to "Нет сети"
        !internet && measuring -> Ui.AMBER to "Проверка…"
        !internet -> Ui.AMBER to "Нет доступа в интернет"
        else -> Ui.GREEN to "Онлайн"
    }
    val speedTxt = speedMbps?.let { if (it >= 100) "%.0f".format(it) else "%.1f".format(it) }
        ?: if (connected && (measuring || updatedAt == 0L)) "…" else "—"
    val netTxt = when (transport) {
        "wifi" -> if (ssid != null) "Wi-Fi · $ssid" else "Wi-Fi"
        "cell" -> "Мобильный интернет"
        "other" -> "Другая сеть"
        else -> "Нет подключения"
    }
    val vpnTitle = if (vpnOn) "VPN · ${vpnName ?: "включён"}" else "VPN выключен"
    val (detail, detailColor) = when {
        !vpnOn -> "Прямое соединение" to Ui.MUTED
        tlsError != null -> tlsError to Ui.RED
        pingMs != null -> "Пинг $pingMs мс" to
            (if (pingMs < 120) Ui.GREEN else if (pingMs < 300) Ui.AMBER else Ui.RED)
        measuring -> "Измерение…" to Ui.MUTED
        else -> "—" to Ui.MUTED
    }
    val compactVpn = if (!vpnOn) "VPN выкл." else (vpnName ?: "VPN") + " · " + when {
        tlsError != null -> tlsError.substringBefore(":") + " ошибка"
        pingMs != null -> "$pingMs мс"
        else -> "…"
    }
    val compactColor = when {
        !vpnOn -> Ui.MUTED
        tlsError != null -> Ui.RED
        else -> Ui.VIOLET
    }
    return Look(dot, title, speedTxt, netTxt, vpnTitle, detail, detailColor, compactVpn, compactColor)
}

object Store {
    fun prefs(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("netwidget", Context.MODE_PRIVATE)

    fun load(c: Context): NetState = runCatching {
        NetState.fromJson(JSONObject(prefs(c).getString("state", "{}") ?: "{}"))
    }.getOrDefault(NetState())

    fun save(c: Context, s: NetState) {
        prefs(c).edit().putString("state", s.toJson().toString()).apply()
    }
}
