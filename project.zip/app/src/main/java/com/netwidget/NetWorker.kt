package com.netwidget

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class NetWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        lock.withLock {
            val ctx = applicationContext
            val reason = inputData.getString("reason") ?: "periodic"
            val sp = Store.prefs(ctx)
            val prev = Store.load(ctx)
            val now = System.currentTimeMillis()
            val snap = Collector.snapshot(ctx, prev)

            if (reason == "name") { // только обновить подписи
                Store.save(ctx, snap)
                NetWidget.renderAll(ctx)
                return@withLock Result.success()
            }

            val key = "${snap.transport}|${snap.ssid}|${snap.vpnOn}|${sp.getLong("vpnHandle", -1)}"
            val sameKey = key == sp.getString("lastKey", null)
            // Системные коллбэки сыплются часто: если ничего не изменилось — не трогаем сеть
            if (reason == "net" && sameKey && now - prev.updatedAt < 5 * 60_000L) {
                return@withLock Result.success()
            }

            Store.save(ctx, snap.copy(measuring = true))
            NetWidget.renderAll(ctx)

            // Тест скорости тратит трафик: Wi-Fi — раз в 15 мин, мобильная сеть — раз в час
            val speedEvery = (if (snap.transport == "wifi") 15 else 60) * 60_000L
            val speedDue = reason == "manual" || !sameKey || now - sp.getLong("lastSpeedAt", 0) > speedEvery

            val done = try { Collector.measure(ctx, snap, speedDue) } catch (e: Exception) { snap }
            Store.save(ctx, done.copy(measuring = false))
            sp.edit().putString("lastKey", key).also { if (speedDue) it.putLong("lastSpeedAt", now) }.apply()
            NetWidget.renderAll(ctx)
            Result.success()
        }
    }

    companion object {
        private val lock = Mutex()

        fun enqueue(ctx: Context, reason: String, delaySec: Long = 0L) {
            val b = OneTimeWorkRequestBuilder<NetWorker>()
                .setInputData(workDataOf("reason" to reason))
            if (delaySec > 0) b.setInitialDelay(delaySec, TimeUnit.SECONDS)
            else if (reason == "manual") b.setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            WorkManager.getInstance(ctx.applicationContext)
                .enqueueUniqueWork("net-$reason", ExistingWorkPolicy.REPLACE, b.build())
        }

        fun schedulePeriodic(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<NetWorker>(15, TimeUnit.MINUTES)
                .setInputData(workDataOf("reason" to "periodic")).build()
            WorkManager.getInstance(ctx.applicationContext)
                .enqueueUniquePeriodicWork("net-periodic", ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun cancelAll(ctx: Context) {
            val wm = WorkManager.getInstance(ctx.applicationContext)
            listOf("net-periodic", "net-net", "net-manual", "net-name").forEach { wm.cancelUniqueWork(it) }
        }
    }
}
