package com.netwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.SizeF
import android.widget.RemoteViews

/** Основной виджет (по умолчанию 2×2, растягивается до 2×1 и шире). */
open class NetWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        manager.updateAppWidget(ids, build(context, Store.load(context)))
        registerCallback(context)
        NetWorker.schedulePeriodic(context)
        NetWorker.enqueue(context, "net")
    }

    override fun onEnabled(context: Context) {
        registerCallback(context)
        NetWorker.schedulePeriodic(context)
    }

    override fun onDisabled(context: Context) {
        if (!hasWidgets(context)) {
            unregisterCallback(context)
            NetWorker.cancelAll(context)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH -> NetWorker.enqueue(context, "manual")
            ACTION_NET -> NetWorker.enqueue(context, "net", 3)
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.netwidget.REFRESH"
        const val ACTION_NET = "com.netwidget.NET"

        private fun providers(ctx: Context) =
            listOf(NetWidget::class.java, NetWidgetWide::class.java).map { ComponentName(ctx, it) }

        fun hasWidgets(ctx: Context): Boolean {
            val m = AppWidgetManager.getInstance(ctx)
            return providers(ctx).any { m.getAppWidgetIds(it).isNotEmpty() }
        }

        fun renderAll(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val views = build(ctx, Store.load(ctx))
            providers(ctx).forEach {
                val ids = m.getAppWidgetIds(it)
                if (ids.isNotEmpty()) m.updateAppWidget(ids, views)
            }
        }

        /** Лаунчер сам выбирает подходящий макет под текущий размер виджета. */
        fun build(ctx: Context, s: NetState): RemoteViews {
            val compact = RemoteViews(ctx.packageName, R.layout.widget_compact).also { fill(ctx, it, s, false) }
            val wide = RemoteViews(ctx.packageName, R.layout.widget_wide).also { fill(ctx, it, s, true) }
            val large = RemoteViews(ctx.packageName, R.layout.widget_large).also { fill(ctx, it, s, true) }
            return RemoteViews(
                mapOf(
                    SizeF(100f, 40f) to compact,   // 2×1
                    SizeF(250f, 40f) to wide,      // 4×1
                    SizeF(100f, 110f) to large,    // 2×2 и выше
                )
            )
        }

        private fun fill(ctx: Context, v: RemoteViews, s: NetState, full: Boolean) {
            val l = s.look()
            v.setInt(R.id.dot, "setColorFilter", l.dot)
            v.setTextViewText(R.id.speed, l.speed)
            v.setTextViewText(R.id.net, l.net)
            if (full) {
                v.setTextViewText(R.id.title, l.title)
                v.setTextColor(R.id.title, l.dot)
                v.setTextViewText(R.id.vpn, l.vpnTitle)
                v.setTextColor(R.id.vpn, if (s.vpnOn) Ui.VIOLET else Ui.MUTED)
                v.setTextViewText(R.id.vpn_detail, l.vpnDetail)
                v.setTextColor(R.id.vpn_detail, l.detailColor)
            } else {
                v.setTextViewText(R.id.vpn, l.compactVpn)
                v.setTextColor(R.id.vpn, l.compactColor)
            }
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            v.setOnClickPendingIntent(
                R.id.root,
                PendingIntent.getActivity(ctx, 0, Intent(ctx, SwitcherActivity::class.java), flags)
            )
            v.setOnClickPendingIntent(
                R.id.btn_refresh,
                PendingIntent.getBroadcast(
                    ctx, 1, Intent(ctx, NetWidget::class.java).setAction(ACTION_REFRESH), flags
                )
            )
        }

        private fun netPi(ctx: Context) = PendingIntent.getBroadcast(
            ctx, 11, Intent(ctx, NetWidget::class.java).setAction(ACTION_NET),
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        /** Системные уведомления о смене сети (Wi-Fi/моб./VPN) доставляются прямо в виджет. */
        fun registerCallback(ctx: Context) {
            runCatching {
                val cm = ctx.getSystemService(ConnectivityManager::class.java)
                val req = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN) // чтобы видеть и VPN
                    .build()
                cm.registerNetworkCallback(req, netPi(ctx))
            }
        }

        fun unregisterCallback(ctx: Context) {
            runCatching {
                ctx.getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(netPi(ctx))
            }
        }
    }
}

/** Отдельная запись в списке виджетов — сразу 4×1. */
class NetWidgetWide : NetWidget()
