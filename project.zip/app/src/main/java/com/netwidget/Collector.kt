@file:Suppress("DEPRECATION")

package com.netwidget

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.SSLHandshakeException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

object Collector {
    private val PROBES = listOf(
        "https://cp.cloudflare.com/generate_204",
        "https://www.gstatic.com/generate_204",
    )

    /** Быстрый срез без сетевых запросов: тип сети, SSID, наличие VPN. */
    fun snapshot(ctx: Context, prev: NetState): NetState {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val nets = cm.allNetworks.mapNotNull { n -> cm.getNetworkCapabilities(n)?.let { n to it } }
        val vpn = nets.firstOrNull { it.second.hasTransport(NetworkCapabilities.TRANSPORT_VPN) }
        val phys = nets
            .filter {
                !it.second.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
                    it.second.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            }
            .sortedWith(
                compareByDescending<Pair<Network, NetworkCapabilities>> {
                    it.second.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                }.thenByDescending { it.second.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) }
            )
        val base = phys.firstOrNull()?.second
        val now = System.currentTimeMillis()
        val vpnOn = vpn != null
        val vpnName = if (vpn != null) VpnApps.resolveActive(ctx, vpn.first.networkHandle)
        else { VpnApps.clear(ctx); null }

        if (base == null) return NetState(updatedAt = now, vpnOn = vpnOn, vpnName = vpnName)

        val tr = when {
            base.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            base.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cell"
            else -> "other"
        }
        val ssid = if (tr == "wifi" &&
            ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        ) {
            ctx.applicationContext.getSystemService(WifiManager::class.java)
                .connectionInfo?.ssid
                ?.trim('"')
                ?.takeIf { it.isNotBlank() && it != "<unknown ssid>" }
        } else null

        return prev.copy(
            connected = true, transport = tr, ssid = ssid,
            vpnOn = vpnOn, vpnName = vpnName,
            pingMs = if (vpnOn) prev.pingMs else null,
            tlsError = if (vpnOn) prev.tlsError else null,
        )
    }

    /** Блокирующие сетевые замеры. Вызывать только из фонового потока. */
    fun measure(ctx: Context, s: NetState, doSpeed: Boolean): NetState {
        val now = System.currentTimeMillis()
        if (!s.connected) {
            return s.copy(updatedAt = now, internet = false, speedMbps = null, pingMs = null, tlsError = null)
        }
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val active = cm.activeNetwork
            ?: return s.copy(updatedAt = now, internet = false, speedMbps = null, pingMs = null, tlsError = null)

        var ping: Int? = null
        var tls: String? = null
        if (s.vpnOn) {
            val vpnNet = cm.allNetworks.firstOrNull {
                cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
            }
            if (vpnNet != null) {
                val r = tlsPing(vpnNet)
                ping = r.first; tls = r.second
            }
        }
        val internet = probe(active)
        val speed = when {
            !internet -> null
            doSpeed -> speedTest(active, if (s.transport == "wifi") 2_000_000 else 1_000_000) ?: s.speedMbps
            else -> s.speedMbps
        }
        return s.copy(updatedAt = now, internet = internet, speedMbps = speed, pingMs = ping, tlsError = tls)
    }

    private fun probe(n: Network): Boolean = PROBES.any { url ->
        try {
            val c = n.openConnection(URL(url)) as HttpURLConnection
            c.connectTimeout = 4000; c.readTimeout = 4000
            c.instanceFollowRedirects = false; c.useCaches = false
            val ok = c.responseCode == 204
            c.disconnect()
            ok
        } catch (e: Exception) {
            false
        }
    }

    private fun speedTest(n: Network, bytes: Int): Double? = try {
        val c = n.openConnection(URL("https://speed.cloudflare.com/__down?bytes=$bytes")) as HttpURLConnection
        c.connectTimeout = 5000; c.readTimeout = 5000; c.useCaches = false
        val buf = ByteArray(64 * 1024)
        var total = 0L
        val result = c.inputStream.use { ins ->
            val t0 = System.nanoTime()
            while (true) {
                val r = ins.read(buf)
                if (r < 0) break
                total += r
                if (System.nanoTime() - t0 > 6_000_000_000L) break
            }
            val sec = (System.nanoTime() - t0) / 1e9
            if (total < 100_000 || sec <= 0.0) null else total * 8 / sec / 1e6
        }
        c.disconnect()
        result
    } catch (e: Exception) {
        null
    }

    /**
     * «Пинг через VPN»: время ответа на минимальный HTTPS-запрос к Cloudflare,
     * отправленный через VPN-сеть (≈ 1 RTT через туннель). Заодно проверяет TLS-рукопожатие.
     * Возвращает (мс, null) или (null, текст ошибки).
     */
    private fun tlsPing(n: Network): Pair<Int?, String?> {
        val host = "www.cloudflare.com"
        var stage = "dns"
        var raw: Socket? = null
        return try {
            val addr = n.getByName(host)
            stage = "tcp"
            raw = n.socketFactory.createSocket()
            raw.connect(InetSocketAddress(addr, 443), 4000)
            raw.soTimeout = 4000
            stage = "tls"
            val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                .createSocket(raw, host, 443, true) as SSLSocket
            ssl.startHandshake()
            stage = "http"
            val t0 = System.nanoTime()
            ssl.outputStream.apply {
                write("HEAD /cdn-cgi/trace HTTP/1.1\r\nHost: $host\r\nConnection: close\r\n\r\n".toByteArray())
                flush()
            }
            ssl.inputStream.read()
            val ms = ((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1)
            ssl.close()
            ms to null
        } catch (e: Exception) {
            null to describe(stage, e)
        } finally {
            runCatching { raw?.close() }
        }
    }

    private fun describe(stage: String, e: Exception): String = when {
        e is UnknownHostException -> "DNS: не резолвится"
        stage == "tcp" -> if (e is SocketTimeoutException) "TCP: таймаут" else "TCP: нет соединения"
        stage == "tls" -> when {
            e is SocketTimeoutException -> "TLS: таймаут рукопожатия"
            e is SSLHandshakeException -> "TLS: рукопожатие не удалось"
            else -> "TLS: соединение сброшено"
        }
        else -> if (e is ConnectException) "HTTP: нет соединения" else "HTTP: ошибка"
    }
}
